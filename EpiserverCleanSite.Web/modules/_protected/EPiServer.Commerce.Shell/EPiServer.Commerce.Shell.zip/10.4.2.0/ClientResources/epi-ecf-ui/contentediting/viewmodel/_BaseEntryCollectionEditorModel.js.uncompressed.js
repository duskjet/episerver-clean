﻿define("epi-ecf-ui/contentediting/viewmodel/_BaseEntryCollectionEditorModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Evented",
    "dojo/promise/all",
    "dojo/Stateful",
    "dojo/when",
// epi
    "epi/dependency",
    "epi/shell/command/DelegateCommand",
// resources
    "epi/i18n!epi/nls/episerver.shared"
], function(
//dojo
    declare,
    lang,
    Evented,
    all,
    Stateful,
    when,
// epi
    dependency,
    DelegateCommand,
// resources
    sharedResources
){
    return declare([Stateful, Evented], {

        storeKey: null,

        resources: null,

        postscript: function () {
            this.inherited(arguments);

            this.storeRegistry = dependency.resolve("epi.storeregistry");
            this.store = this.store || this.storeRegistry.get(this.storeKey);
            this.metadataManager = this.metadataManager || dependency.resolve("epi.shell.MetadataManager");
        },

        getCommands: function (model, category) {
            var commonSettings = {
                category: category,
                model: model,
                canExecute: true,
                isAvailable: true
            };

            return [
                new DelegateCommand(lang.mixin({
                    name: "remove",
                    label: this.resources.commands.remove,
                    iconClass: "epi-iconClose",
                    delegate: lang.hitch(this, function (cmd) {
                        this.emit("removeCommandEvent");
                    })
                }, commonSettings))
            ];
        },

        addItem: function (item, refItem, before) {
            // summary:
            //      Add new item.
            // item: Object
            //      The item raw data
            // refItem: Object
            //      The reference item (item model instance)
            // before: Boolean
            //      Indicates that the new item should be added before the reference item.
            // tags:
            //      public

            this._setSortOrder(item, refItem, before);
            return when(this.store.add(item), lang.hitch(this, function(data) {
                this.emit("itemAdded", { id: data.id });
            }));
        },

        removeItems: function (models) {
            var promises = [];

            for (var i = 0, j = models.length; i < j; i += 1) {
                promises.push(this.store.remove(models[i].id));
            }

            return all(promises).then(lang.hitch(this, function (removed) {
                this.emit("itemsRemoved");
            }));
        },

        getListCommand: function (availableCommands) {
            return new DelegateCommand({
                name: "add",
                label: this.resources.addlabel,
                tooltip: sharedResources.action.add,
                iconClass: "epi-iconPlus",
                canExecute: true,
                isAvailable: true,
                delegate: lang.hitch(this, this.addItemDelegate)
            });
        },

        addItemDelegate: function () {
            // summary:
            //      execute delegate for add command.
            // tags:
            //      protected

            this.emit("toggleItemEditor", null);
        },

        moveItem: function(item, refItem, before) {
            this._setSortOrder(item, refItem, before);
            return when(this.store.put(item), lang.hitch(this, function(data) {
                this.emit("itemSaved", { id: data.id });
            }));
        },

        _setSortOrder: function (item, refItem, before) {
            if (refItem) {
                // Set sortOrder equal to refItem to place it before
                // The store will update sort index of any items after it
                item.sortOrder = before ? refItem.sortOrder : refItem.sortOrder + 1;
            }
        }

    });
});