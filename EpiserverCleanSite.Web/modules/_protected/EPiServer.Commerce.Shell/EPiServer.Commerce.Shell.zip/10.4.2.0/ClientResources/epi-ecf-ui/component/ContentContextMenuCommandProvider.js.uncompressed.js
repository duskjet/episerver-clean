﻿define("epi-ecf-ui/component/ContentContextMenuCommandProvider", [
// dojo
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/_base/declare",
    "dojo/string",
// dojox
    "dojox/html/entities",
// epi shell
    "epi/dependency",
    "epi/shell/selection",
    "epi/shell/command/withConfirmation",
// epi cms
    "epi-cms/component/ContentContextMenuCommandProvider",
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/NewContent",
    "epi-cms/command/DeleteContent",
    "epi-cms/command/CutContent",
    "epi-cms/command/CopyContent",
    "epi-cms/command/PasteContent",
    "epi-cms/command/TranslateContent",
    "epi-cms/content-approval/command/EditApprovalDefinition",
//  commerce
    "./DeleteCatalogContentHandler",
    "../contentediting/ModelSupport",
// Resources
    "epi/i18n!epi/cms/nls/commerce.components.catalogs.commands",
    "epi/i18n!epi/nls/episerver.shared"
],

function (
// dojo
    array,
    lang,
    declare,
    dojoString,
// dojox
    htmlEntities,
 // epi shell
    dependency,
    Selection,
    withConfirmation,
// epi cms
    ContextMenuCommandProvider,
    ChangeContextCommand,
    NewCatalogCommand,
    DeleteCommand,
    CutCommand,
    CopyCommand,
    PasteCommand,
    TranslateCommand,
    EditApprovalDefinition,
// commerce
    DeleteCatalogContentHandler,
    ModelSupport,
// Resources
    res,
    sharedResources
) {
    // module:
    //      epi-ecf-ui.component.ContentContextMenuCommandProvider

    return declare([ContextMenuCommandProvider], {
        // summary:
        //      Command provider for Commerce content context menu.
        // tags:
        //      public

        _formEditViewName: "formedit",

        postscript: function () {
            // make sure clipboard is shared across widgets
            arguments[0].clipboardManager = this.clipboardManager = dependency.resolve("epi.commerce.global").get("epi.commerce.global.clipboard");

            this.inherited(arguments);

            var commands = this.get("commands");

            // create a separated command for creating new Catalog, to show only one menu item as "New Catalog", 
            // instead of having a popup menu item as New, and one child menu item "Catalog" only.
            var createCommand = lang.mixin(this._createCommand(ModelSupport.contentTypeIdentifier.catalogContent), {
                isAvailable: this.isAvailableFlags
            });
            // customize the label
            createCommand.label = dojoString.substitute(res.addcontent, { name: createCommand.label || "" });
            commands.push(createCommand);

            var changeContext = new ChangeContextCommand({
                category: "context",
                forceContextChange: true,
                viewName: this._formEditViewName
            });
            commands.splice(0, 0, changeContext); //add edit first
            this.set("commands", commands);
        },

        updateCommandModel: function (model) {
            // summary:
            //      Updates model for commands. Overwrite this function to display/hide command based on content types.
            // tags:
            //      protected

            this.inherited(arguments);

            array.some(this.get("commands"), function (command) {
                if (command.isInstanceOf(ChangeContextCommand)) {
                    command.set("model", model);
                }
                if (command.selection) {
                    command.selection.set("data", model ? [{ type: "epi.cms.contentdata", data: model }] : []);
                }

                // Hide translate command from every types, as well as when model is null
                if (!model || command.isInstanceOf(TranslateCommand)) {
                    command.set("isAvailable", false);
                    return;
                }

                // Update delete command, to show a confirmation dialog.
                if (command.isInstanceOf(DeleteCommand)) {
                    this._updateDeleteCommand(command, model);
                }

                var isEditCommand = command.isInstanceOf(ChangeContextCommand) && command.viewName === this._formEditViewName;

                switch (model.typeIdentifier) {
                    case ModelSupport.contentTypeIdentifier.rootContent:
                        // hide every command but Add catalog command from Root content
                        command.set("isAvailable", command.isInstanceOf(NewCatalogCommand) || command.isInstanceOf(EditApprovalDefinition));
                        break;
                    case ModelSupport.contentTypeIdentifier.catalogContent:
                        // Catalog content is not allowed to add new catalog, cut or copy, but we can paste Nodes into it, so just hide cut, copy and add new catalog command.
                        if (command.isInstanceOf(CutCommand) || command.isInstanceOf(CopyCommand)
                            || command.isInstanceOf(NewCatalogCommand)) {
                            command.set("isAvailable", false);
                        }
                        else if (command.isInstanceOf(DeleteCommand) || isEditCommand){
                            command.set("isAvailable", true);
                        }
                        break;
                    default:
                        // For node content, every command but add catalog command (except Translate command is disabled above) is available.
                        if (command.isInstanceOf(NewCatalogCommand)) {
                            command.set("isAvailable", false);
                        }
                        else if (command.isInstanceOf(CutCommand) || command.isInstanceOf(CopyCommand) 
                            || command.isInstanceOf(DeleteCommand) || isEditCommand) {
                            command.set("isAvailable", true);
                        }
                }
            }, this);
        },

        _updateDeleteCommand: function (command, model) {
            // summary:
            //      Update delete command, to show a confirmation dialog.
            //      In case of deleting a Catalog, the confirmation dialog will have a warning icon, and different text, to give a higher warning level.
            // tags:
            //      private

            // since execute function will be modify in withConfirmation, we must back it up.
            if (!command._originalExecute) {
                // keep original execute function
                command._originalExecute = command._execute;
            } else {
                // rollback execute function
                command._execute = command._originalExecute;
            }

            var setting = {
                title: res.deleteconfirmationtitle,
                description: res.deleteconfirmationdescription,
                confirmActionText: sharedResources.action.deletelabel,
                cancelActionText: sharedResources.action.cancel
            };

            // higher warning level when deleting Catalog
            if (model.typeIdentifier === ModelSupport.contentTypeIdentifier.catalogContent) {
                // make sure the input object is un-touched by creating a cloned object, then modify the name property.
                var clonedObject = lang.clone(model);
                clonedObject.name = htmlEntities.encode(clonedObject.name);
                lang.mixin(setting, {
                    iconClass: "epi-iconWarning epi-icon--large epi-icon--colored",
                    title: res.deletecatalogconfirmationtitle,
                    description: dojoString.substitute(res.deletecatalogconfirmationdescription, clonedObject),
                    confirmActionText: res.deletecatalogconfirmationlabel,
                    setFocusOnConfirmButton: false // make Delete button gray
                });
            }

            command = withConfirmation(command, DeleteCatalogContentHandler, setting);
        }
    });
});