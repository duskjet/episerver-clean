﻿define("epi-ecf-ui/contentediting/editors/BundleEntryCollectionReadOnlyEditor", [
    // dojo
    "dojo/_base/declare",

    // epi commerce
    "./ReadOnlyCollectionEditor",
    "../viewmodel/BundleEntryCollectionReadOnlyEditorModel",

    // Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.bundleentrycollectioneditor"
],
function (
    //dojo
    declare,
    
    // epi commerce
    ReadOnlyCollectionEditor,
    BundleEntryCollectionReadOnlyEditorModel,

    res
) {
    return declare([ReadOnlyCollectionEditor], {
        // module: 
        //      epi-ecf-ui/contentediting/editors/BundleEntryCollectionReadOnlyEditor
        // summary:
        //      Represents the Read-only editor widget for bundle entries.

        iconClass: "epi-iconObjectBundle",

        modelType: BundleEntryCollectionReadOnlyEditorModel,

        _renderNoDataMessage: function () {
            this.grid.set("noDataMessage", res.nodatamessage);
            this.inherited(arguments);
        },
               
        changeToView: "bundleview",

        buttonLabel: res.editbuttontext
    });
});