﻿define("epi-ecf-ui/contentediting/viewmodel/AssociationCollectionEditorModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi-ecf-ui
    "./_BaseEntryCollectionEditorModel",
//Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.associationcollectioneditor"
],
function (
//dojo
    declare,
    lang,
    when,
// epi-ecf-ui
    _BaseEntryCollectionEditorModel,
// Resources
    res
) {
    return declare([_BaseEntryCollectionEditorModel], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/AssociationCollectionEditorModel
        // summary:
        //      Represents the model for AssocciationCollectionEditor

        storeKey: "epi.commerce.association",

        resources: res,

        saveItem: function (model) {
            // This is overriden from the base class, and will be called when one item are updated.
            var promise = when(this.store.get(model.id), lang.hitch(this, function(oldItem)
            {
                // groupName and type are part of id so if they are changed we have to
                // create a new item, otherwise update
                if (oldItem.groupName === model.groupName && oldItem.type === model.type) {
                    return this.store.put(model);
                } else {
                    // Clone the model and remove its ID so that JsonRest understands this is a new object
                    // and not an attempt to update an existing object
                    var clone = lang.clone(model);
                    delete clone.id;
                    return when(this.store.remove(oldItem.id), lang.hitch(this, function () {
                        return this.store.add(clone);
                    }));
                }
            }));

            when(promise, lang.hitch(this, function(data) {
                this.emit("itemSaved", { id: data.id });
            }));

            return promise;
        }
    });
});